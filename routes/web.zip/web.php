<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\PeminjamanRuanganController;
use App\Http\Controllers\Admin\JadwalPeminjamanController;
use App\Http\Controllers\User\PenyewaanVidotronController;
use App\Http\Controllers\Admin\PeminjamanVidotronController;
use App\Http\Controllers\Pegawai\JadwalController;
use App\Http\Controllers\User\KegiatanController;
use App\Http\Controllers\Admin\KegiatanController as AdminKegiatanController;
use App\Http\Controllers\RuanganController;
use App\Http\Controllers\Admin\PenyewaanVidotronController as AdminPenyewaanVidotronController;
use App\Http\Controllers\Admin\DashboardController as AdminDashboardController;
use Illuminate\Support\Facades\Route;

// Public Routes
Route::get('/', function () {
    return view('home');
});

// Auth Routes
Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
Route::post('/login', [AuthController::class, 'login']);
Route::get('/register', [AuthController::class, 'showRegister'])->name('register');
Route::post('/register', [AuthController::class, 'register']);
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

// Dashboard berdasarkan role
Route::middleware(['auth'])->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
});

// User Routes
// User Routes
Route::middleware(['auth', 'checkrole:user'])->prefix('user')->name('user.')->group(function () {
    Route::get('/dashboard', [\App\Http\Controllers\User\DashboardController::class, 'index'])->name('dashboard');
    // ... rute lainnya
    
    Route::prefix('peminjaman-ruangan')->name('peminjaman-ruangan.')->group(function () {
        Route::get('/', [PeminjamanRuanganController::class, 'create'])->name('create');
        Route::post('/', [PeminjamanRuanganController::class, 'store'])->name('store');
        Route::get('/riwayat', [PeminjamanRuanganController::class, 'indexUser'])->name('riwayat');
        Route::get('/{id}/detail', [PeminjamanRuanganController::class, 'getDetailUser'])->name('detail'); 
        Route::post('/{id}/cancel', [PeminjamanRuanganController::class, 'cancelUser'])->name('cancel');
    });
    
    Route::get('/peminjaman-video', function () {
        return view('user.peminjaman-video');
    })->name('peminjaman-video');
    
    Route::get('/lihat-jadwal', function () {
        return view('user.lihat-jadwal');
    })->name('lihat-jadwal');
    
    Route::prefix('penyewaan-vidotron')->name('penyewaan-vidotron.')->group(function () {
        Route::get('/', [PenyewaanVidotronController::class, 'index'])->name('index');
        Route::get('/create', [PenyewaanVidotronController::class, 'create'])->name('create');
        Route::post('/', [PenyewaanVidotronController::class, 'store'])->name('store');
        Route::get('/status', [PenyewaanVidotronController::class, 'status'])->name('status');
        Route::get('/riwayat', [PenyewaanVidotronController::class, 'riwayat'])->name('riwayat');
        Route::get('/{id}', [PenyewaanVidotronController::class, 'show'])->name('show');
        Route::get('/{id}/edit', [PenyewaanVidotronController::class, 'edit'])->name('edit');
        Route::put('/{id}', [PenyewaanVidotronController::class, 'update'])->name('update');
        Route::delete('/{id}', [PenyewaanVidotronController::class, 'destroy'])->name('destroy');
        Route::get('/{id}/detail', [PenyewaanVidotronController::class, 'getDetailUser'])->name('detail');
        Route::post('/{id}/cancel', [PenyewaanVidotronController::class, 'cancel'])->name('cancel');
    });
});

// Admin Routes
Route::middleware(['auth', 'checkrole:admin'])
    ->prefix('admin')
    ->name('admin.')
    ->group(function () {

        Route::get('/dashboard', [AdminDashboardController::class, 'index'])
            ->name('dashboard');
    });
  Route::middleware(['auth', 'checkrole:admin'])
    ->prefix('admin')
    ->name('admin.')
    ->group(function () {

        Route::prefix('users')->name('users.')->group(function () {
            Route::get('/', [AdminController::class, 'daftarUsers'])->name('index');
            Route::get('/{user}/data', [AdminController::class, 'getUserData'])->name('data');
            Route::post('/', [AdminController::class, 'storeUser'])->name('store');
            Route::put('/{user}', [AdminController::class, 'updateUserData'])->name('update');
            Route::delete('/{user}', [AdminController::class, 'deleteUser'])->name('destroy');
            Route::patch('/{user}/toggle-status', [AdminController::class, 'toggleUserStatus'])->name('toggle-status');
        });

    });

    Route::middleware(['auth', 'checkrole:admin'])
    ->prefix('admin')
    ->name('admin.')
    ->group(function () {

        Route::prefix('ruangan')->name('ruangan.')->group(function () {
            Route::get('/', [RuanganController::class, 'index'])->name('index');
            Route::get('/statistics', [RuanganController::class, 'getStatistics'])->name('statistics');
            Route::get('/{id}/detail', [RuanganController::class, 'show'])->name('detail');
            Route::post('/', [RuanganController::class, 'store'])->name('store');
            Route::put('/{id}', [RuanganController::class, 'update'])->name('update');
            Route::delete('/{id}', [RuanganController::class, 'destroy'])->name('destroy');
        });

    });

    Route::middleware(['auth', 'checkrole:admin'])
    ->prefix('admin')
    ->name('admin.')
    ->group(function () {

        Route::prefix('peminjaman-ruangan')->name('peminjaman-ruangan.')->group(function () {
            Route::get('/', [PeminjamanRuanganController::class, 'indexAdmin'])->name('index');
            Route::get('/{id}/detail', [PeminjamanRuanganController::class, 'detail'])->name('detail');
            Route::post('/{id}/approve', [PeminjamanRuanganController::class, 'approve'])->name('approve');
            Route::post('/{id}/reject', [PeminjamanRuanganController::class, 'reject'])->name('reject');
            Route::post('/{id}/cancel', [PeminjamanRuanganController::class, 'cancel'])->name('cancel');
            Route::post('/update-status', [PeminjamanRuanganController::class, 'updateStatusRealTime'])->name('update-status');
            Route::get('/{id}/download-surat', [PeminjamanRuanganController::class, 'downloadSurat'])->name('download-surat');
        });

    });

    
  Route::middleware(['auth', 'checkrole:admin'])
    ->prefix('admin')
    ->name('admin.')
    ->group(function () {

        Route::get('/jadwal-pegawai', [AdminController::class, 'jadwalPegawai'])
            ->name('jadwal-pegawai');

    });

  Route::middleware(['auth', 'checkrole:admin'])
    ->prefix('admin')
    ->name('admin.')
    ->group(function () {

        Route::get('/peminjaman-video', [AdminPenyewaanVidotronController::class, 'peminjamanVideo'])
            ->name('peminjaman-video');

    });

    // Route daftar kegiatan
    Route::get('/daftar-kegiatan', [AdminKegiatanController::class, 'index'])->name('daftar-kegiatan');
    
    Route::post('/bookings/{id}/approve', [AdminController::class, 'approveBooking'])->name('bookings.approve');
    Route::post('/bookings/{id}/reject', [AdminController::class, 'rejectBooking'])->name('bookings.reject');
    
    // ADMIN VIDOTRON ROUTES - YANG LAMA (HAPUS ATAU GANTI)
    /*
    Route::prefix('penyewaan-vidotron')->name('penyewaan-vidotron.')->group(function () {
        Route::get('/', [AdminPenyewaanVidotronController::class, 'peminjamanVideo'])->name('index');
        Route::get('/{penyewaanVidotron}', [AdminPenyewaanVidotronController::class, 'show'])->name('show');
        Route::post('/{penyewaanVidotron}/approve', [AdminPenyewaanVidotronController::class, 'approve'])->name('approve');
        Route::post('/{penyewaanVidotron}/reject', [AdminPenyewaanVidotronController::class, 'reject'])->name('reject');
        Route::delete('/{penyewaanVidotron}', [AdminPenyewaanVidotronController::class, 'destroy'])->name('destroy');
        Route::get('/{penyewaanVidotron}/download-surat', [AdminPenyewaanVidotronController::class, 'downloadSurat'])->name('download-surat');
        Route::get('/{id}/detail', [AdminPenyewaanVidotronController::class, 'detail'])->name('detail');
        Route::get('/semua-jadwal', [JadwalPeminjamanController::class, 'semuaData'])
        ->name('semua-jadwal');
    });
    */

// Test route tanpa middleware custom
Route::get('/test-role', function () {
    $user = auth()->user();
    return response()->json([
        'user' => $user->name,
        'role' => $user->role,
        'is_admin' => $user->role === 'admin'
    ]);
})->middleware('auth');

// Tambahkan route untuk jadwal peminjaman
Route::get('/admin/jadwal-peminjaman', [JadwalPeminjamanController::class, 'index'])
    ->name('admin.jadwal-peminjaman');

// USER: Langsung ke form peminjaman video trone
Route::middleware(['auth'])->group(function () {
    Route::get('/peminjaman-video-trone', [PenyewaanVidotronController::class, 'create'])
        ->name('peminjaman.video-trone');
    
    Route::post('/peminjaman-video-trone', [PenyewaanVidotronController::class, 'store'])
        ->name('peminjaman.video-trone.store');
});

Route::prefix('user')->name('user.')->middleware(['auth'])->group(function () {
    Route::get('/daftar-kegiatan', [KegiatanController::class, 'index'])
        ->name('daftar-kegiatan');
});

// routes/web.php

Route::middleware(['auth', 'checkrole:pegawai'])->prefix('pegawai')->name('pegawai.')->group(function () {
    // Dashboard pegawai
    Route::get('/dashboard', [JadwalController::class, 'dashboardPegawai'])->name('dashboard');
    
    // Jadwal routes lainnya...
    Route::prefix('jadwal')->name('jadwal.')->group(function () {
        Route::get('/', [JadwalController::class, 'index'])->name('index');
        Route::get('/create', [JadwalController::class, 'create'])->name('create');
        Route::post('/', [JadwalController::class, 'store'])->name('store');
        Route::post('/check-availability', [JadwalController::class, 'checkAvailability'])->name('checkAvailability');
        Route::get('/semua', [JadwalController::class, 'semuaKegiatan'])->name('semua');
        Route::get('/{jadwal}', [JadwalController::class, 'show'])->name('show');
       Route::get('/{id}/edit', [JadwalController::class, 'edit'])->name('edit'); // Perbaiki parameter
        Route::put('/{id}', [JadwalController::class, 'update'])->name('update'); // Perbaiki parameter
        Route::delete('/{id}', [JadwalController::class, 'destroy'])->name('destroy'); // Perbaiki parameter
        Route::get('/{id}/data', [JadwalController::class, 'getJadwalData'])->name('data'); // Route untuk AJAX
    });
    
    // Halaman jadwal staff
    Route::get('/jadwal-staff', [JadwalController::class, 'index'])->name('jadwal-staff');
    
    // Halaman buat jadwal
    Route::get('/buat-jadwal', [JadwalController::class, 'create'])->name('buat-jadwal');
    
    // Halaman semua kegiatan
    Route::get('/semua-kegiatan', [JadwalController::class, 'semuaKegiatan'])->name('semua-kegiatan');
});

 // PEMINJAMAN RUANGAN - Untuk edit dan delete
    Route::prefix('peminjaman-ruangan')->name('peminjaman-ruangan.')->group(function () {
        Route::get('/{id}/edit', [PeminjamanRuanganController::class, 'edit'])->name('edit');
        Route::put('/{id}', [PeminjamanRuanganController::class, 'update'])->name('update');
        Route::delete('/{id}', [PeminjamanRuanganController::class, 'destroy'])->name('destroy');
    });

// ============================================
// ADMIN VIDOTRON ROUTES YANG DIPERBAIKI
// ============================================

Route::middleware(['auth', 'checkrole:admin'])
    ->prefix('admin')
    ->name('admin.')
    ->group(function () {
        
        Route::prefix('penyewaan-vidotron')->name('penyewaan-vidotron.')->group(function () {
            Route::get('/', [AdminPenyewaanVidotronController::class, 'index'])->name('index');
            Route::get('/{id}/detail', [AdminPenyewaanVidotronController::class, 'detail'])->name('detail');
            Route::post('/{id}/approve', [AdminPenyewaanVidotronController::class, 'approve'])->name('approve');
            Route::post('/{id}/reject', [AdminPenyewaanVidotronController::class, 'reject'])->name('reject');
            Route::post('/{id}/cancel', [AdminPenyewaanVidotronController::class, 'cancel'])->name('cancel');
            Route::delete('/{id}', [AdminPenyewaanVidotronController::class, 'destroy'])->name('destroy');
            Route::get('/{id}/download-surat', [AdminPenyewaanVidotronController::class, 'downloadSurat'])->name('download-surat');
        });
        
    });

// Fallback route
Route::fallback(function () {
    return view('errors.404');
});

Route::middleware(['auth', 'checkrole:admin'])
    ->prefix('admin')
    ->name('admin.')
    ->group(function () {

    // ===== DASHBOARD =====
    Route::get('/dashboard', [AdminDashboardController::class, 'index'])
        ->name('dashboard');

    // ===== USERS =====
    Route::prefix('users')->name('users.')->group(function () {
        Route::get('/', [AdminController::class, 'daftarUsers'])->name('index');
        Route::get('/{user}/data', [AdminController::class, 'getUserData'])->name('data');
        Route::post('/', [AdminController::class, 'storeUser'])->name('store');
        Route::put('/{user}', [AdminController::class, 'updateUserData'])->name('update');
        Route::delete('/{user}', [AdminController::class, 'deleteUser'])->name('destroy');
        Route::patch('/{user}/toggle-status', [AdminController::class, 'toggleUserStatus'])->name('toggle-status');
    });

    // ===== RUANGAN =====
    Route::prefix('ruangan')->name('ruangan.')->group(function () {
        Route::get('/', [RuanganController::class, 'index'])->name('index');
        Route::get('/statistics', [RuanganController::class, 'getStatistics'])->name('statistics');
        Route::get('/{id}/detail', [RuanganController::class, 'show'])->name('detail');
        Route::post('/', [RuanganController::class, 'store'])->name('store');
        Route::put('/{id}', [RuanganController::class, 'update'])->name('update');
        Route::delete('/{id}', [RuanganController::class, 'destroy'])->name('destroy');
    });

    // ===== PEMINJAMAN RUANGAN =====
    Route::prefix('peminjaman-ruangan')->name('peminjaman-ruangan.')->group(function () {
        Route::get('/', [PeminjamanRuanganController::class, 'indexAdmin'])->name('index');
        Route::get('/{id}/detail', [PeminjamanRuanganController::class, 'detail'])->name('detail');
        Route::post('/{id}/approve', [PeminjamanRuanganController::class, 'approve'])->name('approve');
        Route::post('/{id}/reject', [PeminjamanRuanganController::class, 'reject'])->name('reject');
        Route::post('/{id}/cancel', [PeminjamanRuanganController::class, 'cancel'])->name('cancel');
        Route::post('/update-status', [PeminjamanRuanganController::class, 'updateStatusRealTime'])->name('update-status');
        Route::get('/{id}/download-surat', [PeminjamanRuanganController::class, 'downloadSurat'])->name('download-surat');
    });

    // ===== JADWAL PEGAWAI =====
    Route::get('/jadwal-pegawai', [AdminController::class, 'jadwalPegawai'])
        ->name('jadwal-pegawai');

    // ===== PEMINJAMAN VIDOTRON =====
    Route::get('/peminjaman-video', [AdminPenyewaanVidotronController::class, 'peminjamanVideo'])
        ->name('peminjaman-video');

    Route::prefix('user')->name('user.')->middleware(['auth'])->group(function () {

    Route::get('/peminjaman-video', [AdminPenyewaanVidotronController::class, 'peminjamanVideo'])
        ->name('peminjaman-video');

    Route::post('/peminjaman-video', [AdminPenyewaanVidotronController::class, 'storePeminjamanVideo'])
        ->name('peminjaman-video.store');

});

    // ===== ROUTES VIDOTRON YANG DIKONSOLIDASI =====
    Route::prefix('penyewaan-vidotron')->name('penyewaan-vidotron.')->group(function () {
        Route::get('/', [AdminPenyewaanVidotronController::class, 'peminjamanVideo'])->name('index');
        Route::get('/{id}/detail', [AdminPenyewaanVidotronController::class, 'detail'])->name('detail');
        Route::post('/{id}/approve', [AdminPenyewaanVidotronController::class, 'approve'])->name('approve');
        Route::post('/{id}/reject', [AdminPenyewaanVidotronController::class, 'reject'])->name('reject');
        Route::post('/{id}/cancel', [AdminPenyewaanVidotronController::class, 'cancel'])->name('cancel');
        Route::delete('/{id}', [AdminPenyewaanVidotronController::class, 'destroy'])->name('destroy');
        Route::get('/{id}/download-surat', [AdminPenyewaanVidotronController::class, 'downloadSurat'])->name('download-surat');
    });

    // ===== KEGIATAN =====
    Route::get('/daftar-kegiatan', [AdminKegiatanController::class, 'index'])
        ->name('daftar-kegiatan');

    // ===== SEMUA JADWAL =====
    Route::get('/semua-jadwal', [JadwalPeminjamanController::class, 'semuaData'])
        ->name('semua-jadwal');

        
});